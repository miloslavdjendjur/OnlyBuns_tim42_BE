package rs.ac.uns.ftn.informatika.jpa.listener;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import rs.ac.uns.ftn.informatika.jpa.model.CareLocation;
import rs.ac.uns.ftn.informatika.jpa.repository.CareLocationRepository;

@Component
public class CareLocationListener {

    private final CareLocationRepository repository;

    public CareLocationListener(CareLocationRepository repository) {
        this.repository = repository;
    }

    @RabbitListener(queues = "care-location-queue")
    public void receiveLocation(CareLocation careLocation) {
        repository.save(careLocation);
    }
}

package rs.ac.uns.informatika.care.service;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;
import rs.ac.uns.informatika.care.config.RabbitConfig;
import rs.ac.uns.informatika.care.model.LocationMessage;

@Service
public class LocationSender {
    private final RabbitTemplate rabbitTemplate;

    public LocationSender(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void send(LocationMessage message) {
        rabbitTemplate.convertAndSend(RabbitConfig.CARE_LOCATION_QUEUE, message);
    }
}

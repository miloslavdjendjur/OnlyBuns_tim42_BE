package rs.ac.uns.informatika.care;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitCareApp {
    public static void main(String[] args) {
        SpringApplication.run(RabbitCareApp.class, args);
    }
}

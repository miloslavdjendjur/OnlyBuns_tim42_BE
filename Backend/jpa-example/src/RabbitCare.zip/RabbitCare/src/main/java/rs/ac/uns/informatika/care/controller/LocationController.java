package rs.ac.uns.informatika.care.controller;

import org.springframework.web.bind.annotation.*;
import rs.ac.uns.informatika.care.model.LocationMessage;
import rs.ac.uns.informatika.care.service.LocationSender;

@RestController
@RequestMapping("/api/care")
@CrossOrigin
public class LocationController {
    private final LocationSender sender;

    public LocationController(LocationSender sender) {
        this.sender = sender;
    }

    @PostMapping("/send")
    public String sendMessage(@RequestBody LocationMessage message) {
        sender.send(message);
        return "Message sent!";
    }
}
